package com.cg.controller;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;



import org.springframework.stereotype.Service;

import com.cg.beans.Employee;

@Service
public class DAOImpl {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("SpringRestFulDataDemo");
	EntityTransaction tx = null;
	
	public Employee insert(Employee employee)
	{
		EntityManager em = emf.createEntityManager();
		tx = em.getTransaction();
		tx.begin();
		em.persist(employee);
		tx.commit();
		return employee;
	}
	
	public Employee deleteEmployee(int id){
		EntityManager em = emf.createEntityManager();
		tx = em.getTransaction();
		tx.begin();
		Employee employee=em.find(Employee.class, id);
		if(employee!=null)
			em.remove(employee);
		em.flush();
		tx.commit();
		em.close();
		return employee;
	}
	public Employee findEmployeeById(int id) {
		EntityManager em = emf.createEntityManager();
		tx = em.getTransaction();
		tx.begin();
		return em.find(Employee.class, id);	
	}
	public Employee updateEmployee(Employee employee) {
		List<Employee> empList=employeeList();
		Iterator itr= empList.iterator();
		Employee currentEmp=null;
		 int count=0;
		EntityManager em = emf.createEntityManager();
		tx = em.getTransaction();
		tx.begin();
		Query qn=null;
		while (itr.hasNext()) {
			Employee updateEmployee = (Employee) itr.next();
			if(updateEmployee.getId()==employee.getId()){
				qn=em.createQuery("UPDATE EMPLOYEE e SET e.eid = '" +employee.getId()+ "' , e.ename = '" + employee.getName() + "' WHERE e.eid = '" + updateEmployee.getId() + "'");
			count=qn.executeUpdate();
			tx.commit();
			}
			
		}
		//em.merge(employee);
		currentEmp =findEmployeeById(employee.getId());
		return currentEmp;

	}
	public List<Employee> employeeList(){
		EntityManager em = emf.createEntityManager();
		 Query q = em.createQuery("from EMPLOYEE e", Employee.class);
	        return q.getResultList();
	}
  

}
