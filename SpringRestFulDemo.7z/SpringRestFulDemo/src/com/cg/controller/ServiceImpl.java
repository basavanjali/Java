package com.cg.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Employee;

@Service
public class ServiceImpl {
	@Autowired
	DAOImpl daoImpl;

	public Employee addEmployee(Employee employee){
		return daoImpl.insert(employee);
	}

	public Employee deleteEmployee(int id) {
		  
		return daoImpl.deleteEmployee(id);
	}

	public Employee findEmployeeById(int id) {
		return daoImpl.findEmployeeById(id);
	}

	public Employee updateEmployee(Employee employee) {
		return daoImpl.updateEmployee(employee);
	}
	public List<Employee> employeeList(){
		return daoImpl.employeeList();
	}

}