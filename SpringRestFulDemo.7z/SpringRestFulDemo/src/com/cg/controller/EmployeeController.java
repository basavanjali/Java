package com.cg.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Employee;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	final static Logger log = Logger.getLogger(EmployeeController.class);

	@Autowired
	ServiceImpl serviceImpl;
	
	/*
	 * This rest call will insert employee data in database.*	
	 */

	@RequestMapping(value="/add", method=RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
		log.info("Employee add call started");
		Employee employee3=	serviceImpl.addEmployee(employee);
		if (employee3 == null) {
            return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
        }
		return new ResponseEntity<Employee>(employee3, HttpStatus.OK);
	}
	/*
	 * This rest call will delete employee data in database.*	
	 */

	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> deleteEmployee(@PathVariable("id") int id){	
		log.info("delete employee call started");
	Employee delVal= serviceImpl.deleteEmployee(id);
	if(delVal==null){
		return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<Employee>(delVal, HttpStatus.OK);
	}
	/*
	 * This rest call will find the employee by id from database.*	
	 */

	@RequestMapping(value="/findEmployeeById/{id}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> findEmployee(@PathVariable("id") int id){
		log.info("Find employee call started");
		Employee employee= serviceImpl.findEmployeeById(id);
		if (employee == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
        }
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
	/*
	 * This rest call will update employee data in database.*	
	 */

	@RequestMapping(value="/update", method=RequestMethod.PUT,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee){
		log.info("update employee call started");
	 Employee employee2=serviceImpl.updateEmployee(employee);
	 if (employee2==null) {
         return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
     }
	 return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
	@RequestMapping(value="/listAll", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> employeeList(){
		return serviceImpl.employeeList();
	}
}
