package com.cg.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDaoImpl customerDao;

	public Customer saveUser(Customer customer) {
		return  customerDao.insertCustomer(customer);
		  
	}
	
	@Override
	public Customer findById(long id) {
		return customerDao.getCustomer(id);
	}

	
	@Override
	public Customer findByName(String name) {
		
		return null;
	}

	

	@Override
	public void updateUser(Customer customer,long id) {
		customerDao.updateCustomer(customer, id);
		
	}

	@Override
	public Customer deleteUserById(long id) {
		 return customerDao.deleteCustomer(id);
		
	}

	@Override
	public List<Customer> findAllUsers() {
		return customerDao.getAllCustomers();
		
		
	}

	@Override
	public boolean deleteAllUsers() {
	 return customerDao.deleteAllCustomers();
	
	}

	@Override
	public boolean isUserExist(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}
//private static final AtomicLong counter = new AtomicLong();
//    
//    private static List<Customer> customers;
//     
//    static{
//        customers= populateDummyCustomers();
//    }

	@Override
	public void updateUser(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUserById(Customer customer, long id) {
		// TODO Auto-generated method stub
		
	}

	

}
