package com.cg.demo;

import java.util.List;

public interface CustomerService {
	 Customer findById(long id);
     
	 Customer findByName(String name);
	     
	   Customer saveUser(Customer customer);
	     
	    void updateUser(Customer customer);
	     
	    Customer deleteUserById(long id);
	 
	    List<Customer> findAllUsers(); 
	     
	    boolean deleteAllUsers();
	     
	    public boolean isUserExist(Customer customer);

		void updateUser(Customer customer, long id);

		void deleteUserById(Customer customer, long id);
}
