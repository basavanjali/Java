package com.cg.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Demorest {
@ResponseBody
 @RequestMapping(value="/demo", method=RequestMethod.GET)
	public String Demo(){
	 System.out.println("hiii");
		return "Success";
	}
 @RequestMapping(value="/demo1", method=RequestMethod.POST)
	public String Demo2(){
		return "Success1";
	}
 
 @RequestMapping(value="/demo2", method=RequestMethod.PUT)
	public String Demo3(){
		return "Success2";
	}
}
