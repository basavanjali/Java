package com.cg.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	

@RequestMapping(value = "/savecustomer", method = RequestMethod.POST,produces= MediaType.APPLICATION_JSON_VALUE)
public Customer createCustomer(@RequestBody Customer customer) {	
	return customerService.saveUser(customer);
}
@RequestMapping(value = "/updatecustomer/{id}", method = RequestMethod.PUT,produces= MediaType.APPLICATION_JSON_VALUE)
public void updateCustomer(@RequestBody Customer customer ,@PathVariable("id") long id) {	
	 customerService.updateUser(customer, id);;
}

@RequestMapping(value = "/get/{id}", method = RequestMethod.GET ,produces= MediaType.APPLICATION_JSON_VALUE)
public Customer getCustomer(@PathVariable("id") long id) {	
	return customerService.findById(id);
}
@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE ,produces= MediaType.APPLICATION_JSON_VALUE)
public Customer deleteCustomer(@PathVariable("id") long id) {	
	 return customerService.deleteUserById(id);
}
@RequestMapping(value = "/getallcustomers", method = RequestMethod.GET ,produces= MediaType.APPLICATION_JSON_VALUE)
public List<Customer> getAllCustomers() {	
	return customerService.findAllUsers();
}
@RequestMapping(value = "/deleteallcustomers", method = RequestMethod.DELETE ,produces= MediaType.APPLICATION_JSON_VALUE)
public boolean deleteAllCustomers() {	
	 return customerService.deleteAllUsers();
}
 @RequestMapping(value="/demo", method=RequestMethod.GET)
	public String Demo(){
	 System.out.println("hiii");
		return "Success";
	}
 @RequestMapping(value="/demo1", method=RequestMethod.POST)
	public String Demo2(){
		return "Success1";
	}
 
 @RequestMapping(value="/demo2", method=RequestMethod.PUT)
	public String Demo3(){
		return "Success2";
	}
}
