package com.cg.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class CustomerDaoImpl {
	public static List<Customer> customers= new ArrayList<Customer>();

	public Customer insertCustomer(Customer customer){
		customers.add(customer);
		System.out.println("ListSize:" +customers.size());
		return customer;}
	public Customer getCustomer(long id){
		return customers.get((int) id);
	}
	public Customer deleteCustomer(long id){
		return customers.remove((int)id);
		
	
	}
	public List<Customer> getAllCustomers(){
		return customers;
	}
	public boolean deleteAllCustomers(){
		return customers.removeAll(customers);
		 
	}
	public Customer updateCustomer(Customer customer,long id){
		customers.set((int) id, customer);
		return customer;
	}
	
}
